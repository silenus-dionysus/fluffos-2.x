void foo() {
    (: $1000 :);
}
