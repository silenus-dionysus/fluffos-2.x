void do_tests() {
    set_hide(1);
    set_hide(0);
}
