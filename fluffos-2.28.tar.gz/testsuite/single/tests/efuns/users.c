void do_tests() {
    ASSERT(arrayp(users()));
    if (this_player())
	ASSERT(member_array(this_player(), users()) != -1);
}
