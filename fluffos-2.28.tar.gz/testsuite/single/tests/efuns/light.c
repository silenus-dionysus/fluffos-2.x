void create() {
#ifndef __NO_LIGHT__
    set_light(3);
#endif
}

void move(object ob) {
#ifndef __NO_ENVIRONMENT__
    move_object(ob);
#endif
}
