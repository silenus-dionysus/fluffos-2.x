void do_tests() {
#ifdef __PRIVS__
    ASSERT(query_privs(this_object()));
#endif
}
