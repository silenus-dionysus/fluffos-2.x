/* this file is used by commands/speed.c */
void ifun() {
}
