#include <command.h>

int
main(string arg)
{
	shutdown(0);
	return 1;
}
