#include "spec.h"

string hash(string, string);
