#ifndef ASYNC_H_
#define ASYNC_H_

void check_reqs();
void complete_all_asyncio();
#endif /*ASYNC_H_*/
